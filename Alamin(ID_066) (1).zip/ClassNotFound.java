public class ClassNotFound {

        public static void main(String[] args) {
            try {
                // Attempt to load a class that does not exist
                System.out.println (Class.forName("myclass"));
                System.out.println("this class exist");
            } catch (ClassNotFoundException e) {
                System.out.println(" Class Not Found Exception " );
            }
        }


}
