class MyClass {

    public void sayHello() {
        System.out.println("Hello World");
    }
}

public class NoSuchMethod {
    public static void main(String[] args) {
        try {
            MyClass myClass = new MyClass();

            // Attempt to access a non-existent method

            System.out.println( myClass.getClass().getMethod("display"));
            System.out.println("method found");
        } catch (NoSuchMethodException e) {
            System.out.println(" No Such Method Exception " );
        }
    }
}

