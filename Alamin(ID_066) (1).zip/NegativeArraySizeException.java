public class NegativeArraySizeException {
    public static void main(String[] args) {

        try{

            int []arr=new int[-5];

        }
        catch (Exception e){
            System.out.println("Negative array size  " +e.getMessage());
        }
    }

}
