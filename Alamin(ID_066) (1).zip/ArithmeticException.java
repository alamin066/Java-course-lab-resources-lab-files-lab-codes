public class ArithmeticException {
    public static void main(String[] args) {

        try {
            int a = 25 / 0;
            System.out.println(a);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
