public class IllegalArgumentException {
    public static void main(String[] args) {
        try {
            setAge(-19);           // Passing negative age to the method
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void setAge(int age) {
        if (age < 0) {
            throw new java.lang.IllegalArgumentException("Age can not be negative");
        }
        System.out.println("Age set to: " + age);
    }
}
