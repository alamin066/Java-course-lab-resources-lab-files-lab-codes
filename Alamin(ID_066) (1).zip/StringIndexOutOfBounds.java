public class StringIndexOutOfBounds {
    public static void main(String[] args) {
        String s="BUBT";
        try{
            System.out.println(s.charAt(5));

        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
