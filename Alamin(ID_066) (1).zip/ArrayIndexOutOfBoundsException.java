public class ArrayIndexOutOfBoundsException {
    public static void main(String[] args) {
       int []arr=new int [3];
       arr[0]=1;
       arr[1]=2;
       arr[2]=3;

        try{
          arr[3]=4;
            System.out.println(arr[3]);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
